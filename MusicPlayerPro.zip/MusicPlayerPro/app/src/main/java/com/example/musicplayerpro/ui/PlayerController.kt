package com.example.musicplayerpro.ui

import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.musicplayerpro.data.Song
import com.example.musicplayerpro.playback.PlayerService

object PlayerController {

    fun send(context: Context, action: String, configure: Intent.() -> Unit = {}) {
        val intent = Intent(context, PlayerService::class.java)
            .setAction(action)
            .apply(configure)

        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
        else context.startService(intent)
    }

    fun playQueue(context: Context, songs: List<Song>, index: Int, queueName: String) {
        val uris = ArrayList(songs.map { it.uri })
        send(context, PlayerService.ACTION_SET_QUEUE) {
            putStringArrayListExtra(PlayerService.EXTRA_QUEUE_URIS, uris)
            putExtra(PlayerService.EXTRA_QUEUE_NAME, queueName)
        }
        send(context, PlayerService.ACTION_PLAY_INDEX) {
            putExtra(PlayerService.EXTRA_INDEX, index)
        }
    }

    fun toggle(context: Context) = send(context, PlayerService.ACTION_TOGGLE)
    fun next(context: Context) = send(context, PlayerService.ACTION_NEXT)
    fun previous(context: Context) = send(context, PlayerService.ACTION_PREVIOUS)
    fun shuffle(context: Context) = send(context, PlayerService.ACTION_SHUFFLE)
    fun repeat(context: Context) = send(context, PlayerService.ACTION_REPEAT)

    fun seek(context: Context, positionMs: Long) =
        send(context, PlayerService.ACTION_SEEK) {
            putExtra(PlayerService.EXTRA_POSITION, positionMs)
        }

    fun setSpeed(context: Context, speed: Float) =
        send(context, PlayerService.ACTION_SPEED) {
            putExtra(PlayerService.EXTRA_SPEED, speed)
        }

    fun setSleepTimer(context: Context, minutes: Int) =
        send(context, PlayerService.ACTION_SLEEP_TIMER) {
            putExtra(PlayerService.EXTRA_MINUTES, minutes)
        }

    fun setEqualizerEnabled(context: Context, enabled: Boolean) =
        send(context, PlayerService.ACTION_EQUALIZER_ENABLED) {
            putExtra(PlayerService.EXTRA_ENABLED, enabled)
        }

    fun setEqualizerBand(context: Context, band: Int, level: Int) =
        send(context, PlayerService.ACTION_EQUALIZER_BAND) {
            putExtra(PlayerService.EXTRA_BAND, band)
            putExtra(PlayerService.EXTRA_LEVEL, level)
        }

    fun setEqualizerPreset(context: Context, preset: Int) =
        send(context, PlayerService.ACTION_EQUALIZER_PRESET) {
            putExtra(PlayerService.EXTRA_PRESET, preset)
        }
}
