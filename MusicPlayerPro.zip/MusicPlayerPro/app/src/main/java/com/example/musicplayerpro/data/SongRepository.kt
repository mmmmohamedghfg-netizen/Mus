package com.example.musicplayerpro.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

object SongRepository {

    fun loadSongs(context: Context): List<Song> {
        val songs = mutableListOf<Song>()
        val collection = if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 30000"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        context.contentResolver.query(collection, projection, selection, null, sortOrder)?.use { cursor ->
            val idC = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleC = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistC = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumC = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdC = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durationC = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idC)
                val albumId = cursor.getLong(albumIdC)
                val artUri = Uri.parse("content://media/external/audio/albumart")
                    .buildUpon().appendPath(albumId.toString()).build().toString()

                songs.add(
                    Song(
                        id = id,
                        title = cursor.getString(titleC) ?: "Unknown",
                        artist = cursor.getString(artistC) ?: "Unknown",
                        album = cursor.getString(albumC) ?: "Unknown",
                        albumId = albumId,
                        durationMs = cursor.getLong(durationC),
                        uri = ContentUris.withAppendedId(collection, id).toString(),
                        artUri = artUri
                    )
                )
            }
        }

        return songs
    }
}
