package com.example.musicplayerpro.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.musicplayerpro.R
import com.example.musicplayerpro.data.Song
import com.example.musicplayerpro.db.AppDatabase
import com.example.musicplayerpro.db.FavoriteEntity
import com.example.musicplayerpro.db.PlaylistEntity
import com.example.musicplayerpro.db.PlaylistSongEntity
import com.example.musicplayerpro.playback.PlaybackState
import kotlinx.coroutines.launch

@Composable
fun SongsScreen() {
    var query by remember { mutableStateOf("") }
    var sortMode by remember { mutableStateOf(SortMode.TITLE) }
    var sortMenuOpen by remember { mutableStateOf(false) }

    val songs = PlaybackState.songs
        .filter {
            query.isBlank() ||
                it.title.contains(query, true) ||
                it.artist.contains(query, true) ||
                it.album.contains(query, true)
        }
        .let { list ->
            when (sortMode) {
                SortMode.TITLE -> list.sortedBy { it.title.lowercase() }
                SortMode.ARTIST -> list.sortedBy { it.artist.lowercase() }
                SortMode.ALBUM -> list.sortedBy { it.album.lowercase() }
                SortMode.DURATION -> list.sortedBy { it.durationMs }
            }
        }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.search)) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true
            )
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = { sortMenuOpen = true }) {
                Icon(Icons.Filled.Sort, contentDescription = "Sort")
            }
            DropdownMenu(expanded = sortMenuOpen, onDismissRequest = { sortMenuOpen = false }) {
                SortMode.entries.forEach { mode ->
                    DropdownMenuItem(
                        text = { Text(mode.label) },
                        onClick = {
                            sortMode = mode
                            sortMenuOpen = false
                        }
                    )
                }
            }
        }

        SongList(
            songs = songs,
            emptyText = stringResource(R.string.no_songs),
            queueName = "كل الأغاني"
        )
    }
}

enum class SortMode(val label: String) {
    TITLE("الاسم"),
    ARTIST("الفنان"),
    ALBUM("الألبوم"),
    DURATION("المدة")
}

@Composable
fun AlbumsScreen() {
    val songs = PlaybackState.songs
    var selectedAlbum by remember { mutableStateOf<String?>(null) }

    val albums = songs.groupBy { it.album }.map { (name, list) ->
        name to list
    }.sortedBy { it.first.lowercase() }

    if (selectedAlbum == null) {
        LazyColumn(Modifier.fillMaxSize()) {
            items(albums, key = { it.first }) { (albumName, albumSongs) ->
                LibraryCard(
                    title = albumName,
                    subtitle = "${albumSongs.size} أغنية",
                    onClick = { selectedAlbum = albumName }
                )
            }
        }
    } else {
        val albumSongs = songs.filter { it.album == selectedAlbum }
        Column {
            Text(
                selectedAlbum ?: "",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(16.dp)
            )
            SongList(
                songs = albumSongs,
                emptyText = stringResource(R.string.no_songs),
                queueName = selectedAlbum ?: ""
            )
        }
    }
}

@Composable
fun ArtistsScreen() {
    val songs = PlaybackState.songs
    var selectedArtist by remember { mutableStateOf<String?>(null) }

    val artists = songs.groupBy { it.artist }.map { (name, list) ->
        name to list
    }.sortedBy { it.first.lowercase() }

    if (selectedArtist == null) {
        LazyColumn(Modifier.fillMaxSize()) {
            items(artists, key = { it.first }) { (artistName, artistSongs) ->
                LibraryCard(
                    title = artistName,
                    subtitle = "${artistSongs.size} أغنية",
                    onClick = { selectedArtist = artistName }
                )
            }
        }
    } else {
        val artistSongs = songs.filter { it.artist == selectedArtist }
        Column {
            Text(
                selectedArtist ?: "",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(16.dp)
            )
            SongList(
                songs = artistSongs,
                emptyText = stringResource(R.string.no_songs),
                queueName = selectedArtist ?: ""
            )
        }
    }
}

@Composable
fun FavoritesScreen() {
    val context = LocalContext.current
    val dao = remember { AppDatabase.get(context).musicDao() }
    val favorites by dao.favoriteIds().collectAsState(initial = emptyList())

    val favoriteSongs = PlaybackState.songs.filter { it.id in favorites }

    SongList(
        songs = favoriteSongs,
        emptyText = "لا توجد أغاني مفضلة بعد",
        queueName = "المفضلة"
    )
}

@Composable
fun LibraryCard(
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 5.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun SongList(
    songs: List<Song>,
    emptyText: String,
    queueName: String
) {
    val context = LocalContext.current
    val dao = remember { AppDatabase.get(context).musicDao() }
    val scope = rememberCoroutineScope()
    val favorites by dao.favoriteIds().collectAsState(initial = emptyList())
    var addToPlaylistSong by remember { mutableStateOf<Song?>(null) }

    if (songs.isEmpty()) {
        EmptyState(text = emptyText)
        return
    }

    LazyColumn(Modifier.fillMaxSize()) {
        itemsIndexed(songs, key = { _, song -> song.id }) { index, song ->
            SongRow(
                song = song,
                isCurrent = PlaybackState.currentSong?.id == song.id,
                isFavorite = song.id in favorites,
                onClick = {
                    PlayerController.playQueue(context, songs, index, queueName)
                },
                onFavorite = {
                    scope.launch {
                        if (song.id in favorites) {
                            dao.removeFavorite(FavoriteEntity(song.id))
                        } else {
                            dao.addFavorite(FavoriteEntity(song.id))
                        }
                    }
                },
                onAddToPlaylist = { addToPlaylistSong = song }
            )
        }
    }

    addToPlaylistSong?.let { song ->
        AddToPlaylistDialog(
            song = song,
            onDismiss = { addToPlaylistSong = null }
        )
    }
}

@Composable
fun SongRow(
    song: Song,
    isCurrent: Boolean,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onFavorite: () -> Unit,
    onAddToPlaylist: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 5.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrent) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        )
    ) {
        Row(
            Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AlbumArt(song = song, size = 48.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song.title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    song.artist,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onFavorite) {
                Icon(
                    if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (isFavorite) MaterialTheme.colorScheme.tertiary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = { menuOpen = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "More")
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.add_to_playlist)) },
                    leadingIcon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    onClick = {
                        menuOpen = false
                        onAddToPlaylist()
                    }
                )
            }
        }
    }
}

@Composable
fun EmptyState(text: String) {
    androidx.compose.foundation.layout.Box(
        Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun AddToPlaylistDialog(
    song: Song,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val dao = remember { AppDatabase.get(context).musicDao() }
    val scope = rememberCoroutineScope()
    val playlists by dao.playlists().collectAsState(initial = emptyList())
    var createOpen by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.add_to_playlist)) },
        text = {
            Column {
                TextButton(onClick = { createOpen = true }) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.new_playlist))
                }

                playlists.forEach { playlist ->
                    TextButton(
                        onClick = {
                            scope.launch {
                                val count = dao.countPlaylistSongs(playlist.id)
                                dao.insertPlaylistSong(
                                    PlaylistSongEntity(playlist.id, song.id, count)
                                )
                                onDismiss()
                            }
                        }
                    ) {
                        Text(playlist.name)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    )

    if (createOpen) {
        AlertDialog(
            onDismissRequest = { createOpen = false },
            title = { Text(stringResource(R.string.new_playlist)) },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text(stringResource(R.string.playlist_name)) },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newName.isNotBlank()) {
                            scope.launch {
                                val playlistId = dao.insertPlaylist(PlaylistEntity(name = newName.trim()))
                                dao.insertPlaylistSong(
                                    PlaylistSongEntity(playlistId, song.id, 0)
                                )
                                newName = ""
                                createOpen = false
                                onDismiss()
                            }
                        }
                    }
                ) { Text(stringResource(R.string.create)) }
            },
            dismissButton = {
                TextButton(onClick = { createOpen = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}
