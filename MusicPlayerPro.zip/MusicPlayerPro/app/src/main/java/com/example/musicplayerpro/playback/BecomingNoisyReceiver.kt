package com.example.musicplayerpro.playback

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BecomingNoisyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == android.media.AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
            val serviceIntent = Intent(context, PlayerService::class.java)
                .setAction(PlayerService.ACTION_PAUSE)
            context.startService(serviceIntent)
        }
    }
}
