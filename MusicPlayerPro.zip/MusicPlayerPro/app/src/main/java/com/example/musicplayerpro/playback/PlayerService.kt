package com.example.musicplayerpro.playback

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.audiofx.Equalizer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.musicplayerpro.MainActivity
import com.example.musicplayerpro.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class PlayerService : Service() {

    private var mediaPlayer: MediaPlayer? = null
    private var equalizer: Equalizer? = null
    private var progressJob: Job? = null
    private var sleepJob: Job? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main)
    private val audioManager by lazy { getSystemService(AUDIO_SERVICE) as AudioManager }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> toggle()
            ACTION_PAUSE -> pause()
            ACTION_NEXT -> playNext()
            ACTION_PREVIOUS -> playPrevious()
            ACTION_SEEK -> seekTo(intent.getLongExtra(EXTRA_POSITION, 0L))
            ACTION_SHUFFLE -> PlaybackState.shuffleEnabled = !PlaybackState.shuffleEnabled
            ACTION_REPEAT -> PlaybackState.repeatOneEnabled = !PlaybackState.repeatOneEnabled
            ACTION_PLAY_INDEX -> {
                val index = intent.getIntExtra(EXTRA_INDEX, -1)
                if (index >= 0) playAt(index)
            }
            ACTION_SET_QUEUE -> {
                val names = intent.getStringArrayListExtra(EXTRA_QUEUE_URIS) ?: arrayListOf()
                PlaybackState.queueName = intent.getStringExtra(EXTRA_QUEUE_NAME) ?: "قائمة التشغيل"
                PlaybackState.queue = PlaybackState.songs.filter { it.uri in names }
            }
            ACTION_SPEED -> {
                val speed = intent.getFloatExtra(EXTRA_SPEED, 1.0f)
                PlaybackState.playbackSpeed = speed
                applySpeed()
            }
            ACTION_SLEEP_TIMER -> {
                val minutes = intent.getIntExtra(EXTRA_MINUTES, 0)
                PlaybackState.sleepTimerMinutes = minutes
                scheduleSleepTimer(minutes)
            }
            ACTION_EQUALIZER_ENABLED -> {
                PlaybackState.equalizerEnabled = intent.getBooleanExtra(EXTRA_ENABLED, false)
                applyEqualizerSettings()
            }
            ACTION_EQUALIZER_BAND -> {
                val band = intent.getIntExtra(EXTRA_BAND, 0)
                val level = intent.getIntExtra(EXTRA_LEVEL, 0)
                if (band in PlaybackState.equalizerLevels.indices) {
                    val levels = PlaybackState.equalizerLevels.toMutableList()
                    levels[band] = level
                    PlaybackState.equalizerLevels = levels
                    PlaybackState.equalizerPreset = -1
                    applyEqualizerSettings()
                }
            }
            ACTION_EQUALIZER_PRESET -> {
                val preset = intent.getIntExtra(EXTRA_PRESET, -1)
                PlaybackState.equalizerPreset = preset
                applyEqualizerSettings()
            }
        }

        if (PlaybackState.currentSong != null) {
            startForeground(NOTIFICATION_ID, buildNotification())
        }

        return START_STICKY
    }

    private fun requestAudioFocus(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setOnAudioFocusChangeListener { }
                .build()
            audioFocusRequest = request
            audioManager.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                { },
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
    }

    private fun abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            audioManager.abandonAudioFocus({ })
        }
    }

    private fun toggle() {
        val player = mediaPlayer ?: return
        if (player.isPlaying) pause() else resume()
    }

    private fun pause() {
        mediaPlayer?.pause()
        PlaybackState.isPlaying = false
        abandonAudioFocus()
    }

    private fun resume() {
        val player = mediaPlayer ?: return
        if (requestAudioFocus()) {
            player.start()
            PlaybackState.isPlaying = true
            startProgressUpdates()
        }
    }

    private fun playAt(index: Int) {
        val queue = PlaybackState.queue
        if (queue.isEmpty() || index !in queue.indices) return

        if (!requestAudioFocus()) return

        PlaybackState.currentIndex = index
        val song = queue[index]

        equalizer?.release()
        equalizer = null
        mediaPlayer?.release()

        mediaPlayer = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            setDataSource(applicationContext, android.net.Uri.parse(song.uri))
            setOnCompletionListener {
                if (PlaybackState.repeatOneEnabled) replayCurrent() else playNext()
            }
            prepare()
            start()
        }

        setupEqualizer()
        applySpeed()

        PlaybackState.isPlaying = true
        PlaybackState.durationMs = mediaPlayer?.duration?.toLong() ?: song.durationMs
        PlaybackState.positionMs = 0L
        startProgressUpdates()
    }

    private fun replayCurrent() {
        val player = mediaPlayer ?: return
        player.seekTo(0)
        player.start()
        PlaybackState.isPlaying = true
        startProgressUpdates()
    }

    private fun playNext() {
        val queue = PlaybackState.queue
        if (queue.isEmpty()) return

        val nextIndex = if (PlaybackState.shuffleEnabled && queue.size > 1) {
            var randomIndex = PlaybackState.currentIndex
            while (randomIndex == PlaybackState.currentIndex) {
                randomIndex = (0 until queue.size).random()
            }
            randomIndex
        } else {
            (PlaybackState.currentIndex + 1) % queue.size
        }

        playAt(nextIndex)
    }

    private fun playPrevious() {
        val queue = PlaybackState.queue
        if (queue.isEmpty()) return

        val previousIndex =
            if (PlaybackState.currentIndex - 1 < 0) queue.size - 1
            else PlaybackState.currentIndex - 1

        playAt(previousIndex)
    }

    private fun seekTo(positionMs: Long) {
        mediaPlayer?.seekTo(positionMs.toInt())
        PlaybackState.positionMs = positionMs
    }

    private fun applySpeed() {
        val player = mediaPlayer ?: return
        val params = player.playbackParams
        params.speed = PlaybackState.playbackSpeed
        player.playbackParams = params
    }

    private fun setupEqualizer() {
        val player = mediaPlayer ?: return
        try {
            equalizer = Equalizer(0, player.audioSessionId)
            applyEqualizerSettings()
        } catch (_: Exception) {
            equalizer = null
        }
    }

    private fun applyEqualizerSettings() {
        val eq = equalizer ?: return
        try {
            eq.enabled = PlaybackState.equalizerEnabled

            if (PlaybackState.equalizerPreset >= 0 &&
                PlaybackState.equalizerPreset < eq.numberOfPresets
            ) {
                eq.usePreset(PlaybackState.equalizerPreset.toShort())
            } else {
                val range = eq.bandLevelRange
                val min = range[0]
                val max = range[1]
                PlaybackState.equalizerLevels.forEachIndexed { index, level ->
                    val clamped = level.coerceIn(min.toInt(), max.toInt())
                    eq.setBandLevel(index.toShort(), clamped.toShort())
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun scheduleSleepTimer(minutes: Int) {
        sleepJob?.cancel()
        if (minutes <= 0) return

        sleepJob = serviceScope.launch {
            delay(minutes * 60_000L)
            pause()
            PlaybackState.sleepTimerMinutes = 0
        }
    }

    private fun startProgressUpdates() {
        progressJob?.cancel()
        progressJob = serviceScope.launch {
            while (isActive) {
                val player = mediaPlayer
                if (player != null && player.isPlaying) {
                    PlaybackState.positionMs = player.currentPosition.toLong()
                }
                delay(500)
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel),
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val contentIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        fun action(action: String): PendingIntent = PendingIntent.getService(
            this, action.hashCode(),
            Intent(this, PlayerService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val playPauseIcon =
            if (PlaybackState.isPlaying) android.R.drawable.ic_media_pause
            else android.R.drawable.ic_media_play

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(PlaybackState.currentSong?.title ?: getString(R.string.app_name))
            .setContentText(PlaybackState.currentSong?.artist ?: "")
            .setContentIntent(contentIntent)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_previous, "Previous", action(ACTION_PREVIOUS))
            .addAction(playPauseIcon, "PlayPause", action(ACTION_TOGGLE))
            .addAction(android.R.drawable.ic_media_next, "Next", action(ACTION_NEXT))
            .build()
    }

    override fun onDestroy() {
        progressJob?.cancel()
        sleepJob?.cancel()
        equalizer?.release()
        mediaPlayer?.release()
        mediaPlayer = null
        abandonAudioFocus()
        super.onDestroy()
    }

    companion object {
        const val ACTION_TOGGLE = "com.example.musicplayerpro.TOGGLE"
        const val ACTION_PAUSE = "com.example.musicplayerpro.PAUSE"
        const val ACTION_NEXT = "com.example.musicplayerpro.NEXT"
        const val ACTION_PREVIOUS = "com.example.musicplayerpro.PREVIOUS"
        const val ACTION_SEEK = "com.example.musicplayerpro.SEEK"
        const val ACTION_SHUFFLE = "com.example.musicplayerpro.SHUFFLE"
        const val ACTION_REPEAT = "com.example.musicplayerpro.REPEAT"
        const val ACTION_PLAY_INDEX = "com.example.musicplayerpro.PLAY_INDEX"
        const val ACTION_SET_QUEUE = "com.example.musicplayerpro.SET_QUEUE"
        const val ACTION_SPEED = "com.example.musicplayerpro.SPEED"
        const val ACTION_SLEEP_TIMER = "com.example.musicplayerpro.SLEEP_TIMER"
        const val ACTION_EQUALIZER_ENABLED = "com.example.musicplayerpro.EQ_ENABLED"
        const val ACTION_EQUALIZER_BAND = "com.example.musicplayerpro.EQ_BAND"
        const val ACTION_EQUALIZER_PRESET = "com.example.musicplayerpro.EQ_PRESET"

        const val EXTRA_POSITION = "position"
        const val EXTRA_INDEX = "index"
        const val EXTRA_QUEUE_URIS = "queue_uris"
        const val EXTRA_QUEUE_NAME = "queue_name"
        const val EXTRA_SPEED = "speed"
        const val EXTRA_MINUTES = "minutes"
        const val EXTRA_ENABLED = "enabled"
        const val EXTRA_BAND = "band"
        const val EXTRA_LEVEL = "level"
        const val EXTRA_PRESET = "preset"

        const val CHANNEL_ID = "music_playback"
        const val NOTIFICATION_ID = 1001
    }
}
