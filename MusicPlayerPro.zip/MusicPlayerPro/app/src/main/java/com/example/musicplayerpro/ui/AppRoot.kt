package com.example.musicplayerpro.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.musicplayerpro.R
import com.example.musicplayerpro.data.SongRepository
import com.example.musicplayerpro.db.AppDatabase
import com.example.musicplayerpro.playback.PlaybackState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class AppTab(val labelRes: Int, val icon: ImageVector) {
    Songs(R.string.songs, Icons.Filled.LibraryMusic),
    Albums(R.string.albums, Icons.Filled.Album),
    Artists(R.string.artists, Icons.Filled.Person),
    Playlists(R.string.playlists, Icons.Filled.QueueMusic),
    Favorites(R.string.favorites, Icons.Filled.Favorite)
}

@Composable
fun AppRoot() {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(AppTab.Songs) }
    var hasPermission by remember { mutableStateOf(false) }
    var showNowPlaying by remember { mutableStateOf(false) }

    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasPermission = granted
        if (granted) loadLibrary(context)
    }

    LaunchedEffect(Unit) {
        hasPermission = context.checkSelfPermission(permission) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        if (hasPermission) loadLibrary(context) else launcher.launch(permission)
    }

    if (!hasPermission) {
        PermissionPlaceholder(onRequest = { launcher.launch(permission) })
        return
    }

    Scaffold(
        bottomBar = {
            Column {
                MiniPlayerBar(onOpen = { showNowPlaying = true })
                NavigationBar {
                    AppTab.entries.forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = { Icon(tab.icon, contentDescription = null) },
                            label = { Text(stringResource(tab.labelRes)) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (selectedTab) {
                AppTab.Songs -> SongsScreen()
                AppTab.Albums -> AlbumsScreen()
                AppTab.Artists -> ArtistsScreen()
                AppTab.Playlists -> PlaylistsScreen()
                AppTab.Favorites -> FavoritesScreen()
            }
        }
    }

    if (showNowPlaying) {
        NowPlayingScreen(onClose = { showNowPlaying = false })
    }
}

private suspend fun loadLibrary(context: android.content.Context) {
    val songs = withContext(Dispatchers.IO) { SongRepository.loadSongs(context) }
    PlaybackState.songs = songs
    if (PlaybackState.queue.isEmpty()) {
        PlaybackState.queue = songs
        PlaybackState.queueName = "كل الأغاني"
    }
}

@Composable
private fun PermissionPlaceholder(onRequest: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                stringResource(R.string.permission_required),
                style = MaterialTheme.typography.bodyLarge
            )
            Button(
                onClick = onRequest,
                modifier = Modifier.padding(top = 16.dp)
            ) {
                Text(stringResource(R.string.grant_permission))
            }
        }
    }
}
