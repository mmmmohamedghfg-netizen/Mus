package com.example.musicplayerpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.musicplayerpro.ui.AppRoot
import com.example.musicplayerpro.ui.theme.MusicPlayerProTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MusicPlayerProTheme {
                AppRoot()
            }
        }
    }
}
