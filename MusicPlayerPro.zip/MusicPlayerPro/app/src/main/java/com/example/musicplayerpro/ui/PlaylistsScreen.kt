package com.example.musicplayerpro.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.musicplayerpro.R
import com.example.musicplayerpro.data.Song
import com.example.musicplayerpro.db.AppDatabase
import com.example.musicplayerpro.db.PlaylistEntity
import com.example.musicplayerpro.db.PlaylistSongEntity
import com.example.musicplayerpro.playback.PlaybackState
import kotlinx.coroutines.launch

@Composable
fun PlaylistsScreen() {
    val context = LocalContext.current
    val dao = remember { AppDatabase.get(context).musicDao() }
    val scope = rememberCoroutineScope()
    val playlists by dao.playlists().collectAsState(initial = emptyList())
    var selectedPlaylist by remember { mutableStateOf<PlaylistEntity?>(null) }
    var createOpen by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    if (selectedPlaylist != null) {
        PlaylistDetailScreen(
            playlist = selectedPlaylist!!,
            onBack = { selectedPlaylist = null }
        )
        return
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { createOpen = true }) {
                Icon(Icons.Filled.Add, contentDescription = "New playlist")
            }
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (playlists.isEmpty()) {
                EmptyState("لا توجد قوائم تشغيل. اضغط + لإنشاء قائمة.")
            } else {
                LazyColumn {
                    items(playlists, key = { it.id }) { playlist ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 5.dp)
                                .clickable { selectedPlaylist = playlist },
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Row(
                                Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(playlist.name, style = MaterialTheme.typography.titleMedium)
                                }
                                IconButton(
                                    onClick = {
                                        scope.launch {
                                            dao.clearPlaylistSongs(playlist.id)
                                            dao.deletePlaylist(playlist)
                                        }
                                    }
                                ) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (createOpen) {
        AlertDialog(
            onDismissRequest = { createOpen = false },
            title = { Text(stringResource(R.string.new_playlist)) },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text(stringResource(R.string.playlist_name)) },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newName.isNotBlank()) {
                            scope.launch {
                                dao.insertPlaylist(PlaylistEntity(name = newName.trim()))
                                newName = ""
                                createOpen = false
                            }
                        }
                    }
                ) { Text(stringResource(R.string.create)) }
            },
            dismissButton = {
                TextButton(onClick = { createOpen = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}

@Composable
fun PlaylistDetailScreen(
    playlist: PlaylistEntity,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val dao = remember { AppDatabase.get(context).musicDao() }
    val scope = rememberCoroutineScope()
    val playlistSongs by dao.playlistSongs(playlist.id).collectAsState(initial = emptyList())

    val songsById = PlaybackState.songs.associateBy { it.id }
    val orderedSongs = playlistSongs.mapNotNull { entry -> songsById[entry.songId] }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("رجوع") }
            Spacer(Modifier.width(8.dp))
            Text(
                playlist.name,
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.weight(1f)
            )
        }

        if (orderedSongs.isEmpty()) {
            EmptyState("القائمة فارغة. أضف أغاني من تبويب الأغاني.")
        } else {
            LazyColumn {
                itemsIndexed(orderedSongs, key = { _, song -> song.id }) { index, song ->
                    val entry = playlistSongs[index]
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                            .clickable {
                                PlayerController.playQueue(
                                    context,
                                    orderedSongs,
                                    index,
                                    playlist.name
                                )
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Row(
                            Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AlbumArt(song = song, size = 44.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(song.title, maxLines = 1)
                                Text(
                                    song.artist,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                            IconButton(
                                enabled = index > 0,
                                onClick = {
                                    scope.launch { moveSong(dao, playlistSongs, index, index - 1) }
                                }
                            ) {
                                Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Up")
                            }
                            IconButton(
                                enabled = index < orderedSongs.size - 1,
                                onClick = {
                                    scope.launch { moveSong(dao, playlistSongs, index, index + 1) }
                                }
                            ) {
                                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Down")
                            }
                            IconButton(
                                onClick = {
                                    scope.launch { dao.deletePlaylistSong(entry) }
                                }
                            ) {
                                Icon(
                                    Icons.Filled.RemoveCircleOutline,
                                    contentDescription = "Remove"
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private suspend fun moveSong(
    dao: com.example.musicplayerpro.db.MusicDao,
    entries: List<PlaylistSongEntity>,
    from: Int,
    to: Int
) {
    if (from !in entries.indices || to !in entries.indices || from == to) return

    val mutable = entries.toMutableList()
    val item = mutable.removeAt(from)
    mutable.add(to, item)

    mutable.forEachIndexed { index, entry ->
        dao.updatePosition(entry.playlistId, entry.songId, index)
    }
}
