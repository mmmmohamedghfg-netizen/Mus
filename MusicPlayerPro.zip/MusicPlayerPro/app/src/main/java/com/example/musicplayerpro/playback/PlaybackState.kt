package com.example.musicplayerpro.playback

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.musicplayerpro.data.Song

object PlaybackState {
    var songs by mutableStateOf<List<Song>>(emptyList())
    var queue by mutableStateOf<List<Song>>(emptyList())
    var queueName by mutableStateOf("كل الأغاني")
    var currentIndex by mutableStateOf(-1)
    var isPlaying by mutableStateOf(false)
    var positionMs by mutableStateOf(0L)
    var durationMs by mutableStateOf(0L)
    var shuffleEnabled by mutableStateOf(false)
    var repeatOneEnabled by mutableStateOf(false)
    var playbackSpeed by mutableStateOf(1.0f)
    var sleepTimerMinutes by mutableStateOf(0)
    var equalizerEnabled by mutableStateOf(false)
    var equalizerLevels by mutableStateOf(listOf(0, 0, 0, 0, 0))
    var equalizerPreset by mutableStateOf(-1)

    val currentSong: Song?
        get() = queue.getOrNull(currentIndex)
}
