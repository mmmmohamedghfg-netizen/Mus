package com.example.musicplayerpro.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.musicplayerpro.R
import com.example.musicplayerpro.playback.PlaybackState

@Composable
fun NowPlayingScreen(onClose: () -> Unit) {
    val context = LocalContext.current
    val song = PlaybackState.currentSong
    var sliderPosition by remember { mutableStateOf<Float?>(null) }
    var speedOpen by remember { mutableStateOf(false) }
    var timerOpen by remember { mutableStateOf(false) }
    var equalizerOpen by remember { mutableStateOf(false) }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.25f),
                        MaterialTheme.colorScheme.background
                    )
                )
                )
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.Close, contentDescription = "Close")
                }
                Spacer(Modifier.weight(1f))
                Text(
                    PlaybackState.queueName,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(24.dp))

            Box(
                Modifier
                    .fillMaxWidth()
                    .height(320.dp),
                contentAlignment = Alignment.Center
            ) {
                if (song != null) {
                    AlbumArt(song = song, size = 300.dp, cornerRadius = 28.dp)
                }
            }

            Spacer(Modifier.height(28.dp))

            Text(
                song?.title ?: "لا يوجد تشغيل",
                style = MaterialTheme.typography.headlineSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                song?.artist ?: "",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(Modifier.height(20.dp))

            Slider(
                value = sliderPosition ?: PlaybackState.positionMs.toFloat(),
                onValueChange = { sliderPosition = it },
                onValueChangeFinished = {
                    sliderPosition?.let { PlayerController.seek(context, it.toLong()) }
                    sliderPosition = null
                },
                valueRange = 0f..PlaybackState.durationMs.toFloat().coerceAtLeast(1f)
            )

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(PlaybackState.positionMs))
                Text(formatTime(PlaybackState.durationMs))
            }

            Spacer(Modifier.height(16.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { PlayerController.shuffle(context) }) {
                    Icon(
                        Icons.Filled.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (PlaybackState.shuffleEnabled) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }
                IconButton(onClick = { PlayerController.previous(context) }) {
                    Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous")
                }
                Card(
                    shape = RoundedCornerShape(50),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    IconButton(
                        onClick = { PlayerController.toggle(context) },
                        modifier = Modifier.size(72.dp)
                    ) {
                        Icon(
                            if (PlaybackState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = "PlayPause",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }
                IconButton(onClick = { PlayerController.next(context) }) {
                    Icon(Icons.Filled.SkipNext, contentDescription = "Next")
                }
                IconButton(onClick = { PlayerController.repeat(context) }) {
                    Icon(
                        if (PlaybackState.repeatOneEnabled) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        contentDescription = "Repeat",
                        tint = if (PlaybackState.repeatOneEnabled) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                TextButton(onClick = { speedOpen = true }) {
                    Icon(Icons.Filled.Speed, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("${PlaybackState.playbackSpeed}x")
                }
                TextButton(onClick = { timerOpen = true }) {
                    Icon(Icons.Filled.Timer, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (PlaybackState.sleepTimerMinutes > 0) {
                            "${PlaybackState.sleepTimerMinutes} د"
                        } else {
                            stringResource(R.string.sleep_timer)
                        }
                    )
                }
                TextButton(onClick = { equalizerOpen = true }) {
                    Icon(Icons.Filled.Tune, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.equalizer))
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }

    if (speedOpen) {
        AlertDialog(
            onDismissRequest = { speedOpen = false },
            title = { Text(stringResource(R.string.playback_speed)) },
            text = {
                Column {
                    listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { speed ->
                        TextButton(
                            onClick = {
                                PlayerController.setSpeed(context, speed)
                                speedOpen = false
                            }
                        ) {
                            Text("${speed}x")
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { speedOpen = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    if (timerOpen) {
        AlertDialog(
            onDismissRequest = { timerOpen = false },
            title = { Text(stringResource(R.string.sleep_timer)) },
            text = {
                Column {
                    listOf(15, 30, 45, 60, 90).forEach { minutes ->
                        TextButton(
                            onClick = {
                                PlayerController.setSleepTimer(context, minutes)
                                timerOpen = false
                            }
                        ) {
                            Text("$minutes دقيقة")
                        }
                    }
                    TextButton(
                        onClick = {
                            PlayerController.setSleepTimer(context, 0)
                            timerOpen = false
                        }
                    ) {
                        Text("إلغاء المؤقت")
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { timerOpen = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    if (equalizerOpen) {
        EqualizerDialog(onDismiss = { equalizerOpen = false })
    }
}

@Composable
private fun EqualizerDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val levels = PlaybackState.equalizerLevels
    val presets = listOf("Flat", "Bass Boost", "Vocal", "Rock", "Pop")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.equalizer)) },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (PlaybackState.equalizerEnabled) "مُفعّل" else "مُعطّل",
                        modifier = Modifier.weight(1f)
                    )
                    androidx.compose.material3.Switch(
                        checked = PlaybackState.equalizerEnabled,
                        onCheckedChange = { PlayerController.setEqualizerEnabled(context, it) }
                    )
                }

                Spacer(Modifier.height(12.dp))

                levels.forEachIndexed { band, level ->
                    Text("Band ${band + 1}: $level dB")
                    Slider(
                        value = level.toFloat(),
                        onValueChange = {
                            PlayerController.setEqualizerBand(context, band, it.toInt())
                        },
                        valueRange = -15f..15f
                    )
                }

                Spacer(Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    presets.forEachIndexed { index, preset ->
                        FilterChip(
                            selected = PlaybackState.equalizerPreset == index,
                            onClick = { PlayerController.setEqualizerPreset(context, index) },
                            label = { Text(preset) }
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    )
}

@Composable
fun MiniPlayerBar(onOpen: () -> Unit) {
    val context = LocalContext.current
    val song = PlaybackState.currentSong ?: return

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .clickable(onClick = onOpen),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AlbumArt(song = song, size = 44.dp, cornerRadius = 10.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    song.artist,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
            IconButton(onClick = { PlayerController.previous(context) }) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous")
            }
            IconButton(onClick = { PlayerController.toggle(context) }) {
                Icon(
                    if (PlaybackState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = "PlayPause"
                )
            }
            IconButton(onClick = { PlayerController.next(context) }) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next")
            }
        }
    }
}

@Composable
fun AlbumArt(
    song: com.example.musicplayerpro.data.Song,
    size: androidx.compose.ui.unit.Dp,
    cornerRadius: androidx.compose.ui.unit.Dp = 12.dp
) {
    coil.compose.AsyncImage(
        model = song.artUri,
        contentDescription = song.album,
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(cornerRadius))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentScale = androidx.compose.ui.layout.ContentScale.Crop
    )
}

fun formatTime(ms: Long): String {
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
