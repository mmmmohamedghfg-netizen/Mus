package com.example.musicplayerpro

import com.example.musicplayerpro.data.Song
import org.junit.Assert.assertEquals
import org.junit.Test

class SongTest {
    @Test
    fun songStoresValuesCorrectly() {
        val song = Song(
            id = 1L,
            title = "Test",
            artist = "Artist",
            album = "Album",
            albumId = 10L,
            durationMs = 120000L,
            uri = "content://test",
            artUri = "content://art"
        )

        assertEquals("Test", song.title)
        assertEquals(10L, song.albumId)
        assertEquals(120000L, song.durationMs)
    }
}
