# Release minification is disabled.
