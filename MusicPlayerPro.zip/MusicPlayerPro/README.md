# Music Player Pro

مشغل موسيقى Android متكامل للأغاني المحلية، مبني بـ Kotlin وJetpack Compose وRoom.

## المميزات

- تشغيل الأغاني المحلية من MediaStore.
- شاشة Now Playing كاملة مع صورة الألبوم وشريط تقدم.
- قوائم تشغيل: إنشاء، حذف، إضافة أغاني، إزالة، وإعادة ترتيب الأغاني.
- المفضلة مع حفظ دائم في Room.
- بحث في الأغاني والفنانين والألبومات.
- فرز حسب الاسم أو الفنان أو الألبوم أو المدة.
- تصفح الألبومات والفنانين.
- Shuffle وتكرار الأغنية.
- سرعة تشغيل من 0.5x إلى 2x.
- مؤقت نوم: 15، 30، 45، 60، 90 دقيقة.
- Equalizer مع 5 نطاقات وPresets.
- إدارة Audio Focus وإيقاف تلقائي عند فصل السماعة.
- تشغيل خلفية مع إشعار تحكم.
- واجهة Compose داكنة عصرية مع أيقونة Adaptive.

## بناء APK من الهاتف

1. ارفع محتويات مجلد `MusicPlayerPro` إلى مستودع GitHub.
2. تأكد أن ملف `.github/workflows/build-apk.yml` موجود في مساره الصحيح.
3. افتح تبويب **Actions**.
4. انتظر انتهاء **Build Android APK** أو اضغط **Run workflow**.
5. نزّل `MusicPlayerPro-debug-apk` من **Artifacts**.

## البناء محليًا

```bash
gradle assembleDebug
```

الملف الناتج:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## ملاحظة

تم إعداد المشروع للبناء عبر GitHub Actions باستخدام Gradle 8.9 وJava 17 وAGP 8.5.2 وKotlin 2.0.20. لم يتم تنفيذ بناء APK فعلي داخل بيئة إنشاء المشروع، لذلك يجب التحقق من نتيجة workflow على GitHub.
